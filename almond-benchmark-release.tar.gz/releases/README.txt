Almond Benchmark by JxThxNxs - Release Files
==========================================

This package contains pre-built binaries for different platforms:

📁 linux-64bit/
   └── mandelbrot_benchmark    (Linux 64-bit executable)

📁 windows-32bit/
   └── (Windows 32-bit build - requires Visual Studio to compile)

📁 windows-64bit/  
   └── (Windows 64-bit build - requires Visual Studio to compile)

🎮 How to Run:
- Linux: ./mandelbrot_benchmark
- Windows: mandelbrot_benchmark.exe

🎯 Controls:
- Mouse: Click to zoom
- WASD: Pan around
- Q/E: Zoom out/in
- R: Reset view
- C: Change color palette
- Space: Toggle auto-zoom
- +/-: Adjust iterations
- B: Run benchmark
- ESC: Exit

🏆 Get your Almond Score and challenge your CPU!

For source code and build instructions, visit:
https://github.com/JxThxNxs/almond-benchmark

Created by JxThxNxs
