#!/bin/bash
echo "Starting Almond Benchmark by JxThxNxs..."
./mandelbrot_benchmark
