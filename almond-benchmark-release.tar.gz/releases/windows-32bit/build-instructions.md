# Windows 32-bit Build Instructions

## Prerequisites
1. Visual Studio 2019 or newer with C++ support
2. vcpkg for SDL2 dependencies

## Setup vcpkg
```cmd
git clone https://github.com/Microsoft/vcpkg.git C:\vcpkg
cd C:\vcpkg
.\bootstrap-vcpkg.bat
.\vcpkg install sdl2:x86-windows
```

## Build Steps
1. Open **"x86 Native Tools Command Prompt for VS"**
2. Navigate to the Almond Benchmark directory
3. Run: `build_windows.bat`
4. Executable will be created at: `build_windows_32bit\bin\Release\mandelbrot_benchmark.exe`

## Alternative Manual Build
```cmd
mkdir build_windows_32bit
cd build_windows_32bit
cmake .. -G "Visual Studio 16 2019" -A Win32 -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake
cmake --build . --config Release
```

The compiled executable will be ready for distribution.
